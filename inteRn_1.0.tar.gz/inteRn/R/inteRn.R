# Created by Carlos C Vera Recio
# last edited October 30, 2021
# a GUI to calculate internal medicine scores quickly
#--------------

# clean environment
rm(list=ls(all=TRUE))

# 1) Mean arterial pressure 
map.calc = function(
  sbp = 117,
  dbp = 76
)
{
  map=(sbp+(2*dbp))/3
  cat("map = ", map);cat('', sep='\n')
  return(map)
}
# map.calc() 

# 2) A-a gradient
Aa.gradient.cal = function(
  age=81,
  FiO2=0.4,
  PaO2=146.3,
  PaCO2=33.2,
  Patm=760,
  R=0.8,
  PH2O=47
)
{
  PAO2 = (FiO2 * (Patm - PH2O)) * (PaCO2 / R)
  Aa.gradient = PAO2 - PaO2
  cat("A-a gradient = ", Aa.gradient);cat('', sep='\n')
  return(Aa.gradient)
}
# Aa.gradient.cal()

# 3) Calcium correction
corrected.calcium.calc = function(
  measured.calcium=8.0,
  albumin=2.4,
  unit="SI"
){
  if(unit == "SI")
  {
    corrected.calcium = measured.calcium + 0.02*(40 - albumin)
  } else if(unit == "Eng")
  {
    corrected.calcium = measured.calcium + 0.02*(40 - albumin)
  }
  
  cat("Corrected calcium= ", corrected.calcium, " in units ", unit);cat('', sep='\n')
  return(corrected.calcium)
}
# corrected.calcium.calc()

# 4) Creatinine Clearance
creatinine.clearance = function(
  sex="male",
  age=78,
  weight=100,
  s.cre=1.58
)
{
  # message
  cat(
    "Please input age in years, weight in pounds and serum creatinine in mg/dL"
  );cat('', sep='\n')
  
  # calc and return
  if(sex == "male")
  {
    CCr=(((140-age)*(weight/2.2))/(72*s.cre))
  } else if(sex=="female")
  {
    CCr=(((140-age)*(weight/2.2))/(72*s.cre))*0.85
  }
  cat("Creatinine clearance", CCr);cat('', sep='\n')
  return(CCr)
}
# creatinine.clearance()

# 5) FENA score
FENa = function(
  urine.sodium=1,
  plasma.sodium=1,
  urine.creatinine=1,
  plasma.creatinine=1
)
{
  FENa = 100*((urine.sodium*plasma.creatinine)/(plasma.sodium*urine.creatinine))
  cat("Fraction of excreted sodium = ", FENa);cat('', sep='\n')
  interpretation = if(FENa > 4)
  {
    'Post Renal'
  }else if(FENa >= 1 & FENa <=4)
  {
    'Intrinsic Renal'
  }else if(FENa < 1)
  {
    'Pre-Renal'
  }
  res = list(
    'fraction of excreted sodium' = FENa,
    'interpretation' = interpretation
  )
  return(res)
}
# FENa()

# # APACHE score
# APACHE.II = function(
#   
# )
# {
#   
# }
# APACHE.II()

# 6) CHADs-VASC
CHADSVASc = function(
  CHF='yes',
  HTN = 'yes',
  Age = 75,
  DM = 'yes',
  Stroke = 'yes',
  Vascular = 'yes',
  sex = 'female'
)
{
  score=0
  if(Age >= 75)
  {
    score = score + 2
  }else if(Age >=65 & Age <75)
  {
    score = score + 1
  }
  if(sex == 'female')
  {
    score = score + 1
  }
  if(Vascular == 'yes')
  {
    score = score + 1
  }
  if(Stroke == 'yes')
  {
    score = score + 2
  }
  if(DM == 'yes')
  {
    score = score + 1
  }
  if(HTN == 'yes')
  {
    score = score + 1
  }
  if(CHF == 'yes')
  {
    score = score + 1
  }
  cat('The CHAD-VASc score for this patient is: ', score);cat('', sep = '\n')
  return(score)
}
CHADSVASc()

# 7) Glasgow Comma Scale
Glasgow = function(
  best.eye.response=4,
  best.verbal.response=5,
  best.motor.response=6,
  mechanical.ventilation=FALSE,
  ask.input = FALSE
)
{
  if(ask.input == 'TRUE')
  {
    # take user input to calculate glasgow comma scale
    best.eye.response = readline(
      prompt = 'Please input score for best eye response: 
      Spontaneous = 4, 
      to verbal command = 3,
      to pain = 2, 
      no eye opening = 1: 
      '
    )
    best.motor.response = readline(
      prompt = 'Please input score for best motor response: 
      Obeys commands = 6, 
      localizes pain = 5,
      withdrawal from pain = 4, 
      flexion to pain = 3, 
      extension to pain = 2, 
      no reponse = 1: 
      '
    )
    if(mechanical.ventilation == FALSE)
    {
      best.verbal.response = readline(
        prompt = 'Please input score for best verbal response: 
        Oriented = 5,
        Confused = 4, 
        Innapropriate words = 3, 
        Incomprehensible sounds = 2, 
        no reponse = 1: 
        '
      )
    }else
    {
        best.verbal.response=1
      }
  }
  glasgow.score = as.integer(best.verbal.response)+as.integer(best.eye.response)+as.integer(best.motor.response)
  cat('Glasgow comma scale for this patient is estimated to be :', glasgow.score);cat('', sep = '\n')
  return(glasgow.score)
}
# Glasgow()

# 8) ICH score
ich.score = function(
  glasgow.score = 15,
  age = 80,
  ich.volume = 30,
  intraventricular='no',
  infratentorial='no'
)
{
  score=0
  if(age > 79)
  {
    score = score + 1
  }
  if(ich.volume >= 30)
  {
    score = score + 1
  }
  if(glasgow.score > 11)
  {
    score = score + 0
  }else if(glasgow.score > 4 & glasgow.score < 12)
  {
    score = score + 1
  }else if(glasgow.score < 5)
  {
    score = score + 2
  }
  if(intraventricular == 'yes')
  {
    score = score+1
  }
  if(infratentorial == 'yes')
  {
    score = score + 1
  }
  cat('ich score is: ', score);cat('', sep = '\n')
  return(score)
}

# 9) 'Maintenance fluids' = Maintenance.Fluids,
Maintenance.Fluids = function(
  weight = 200, 
  units = 'pounds'
)
{
  if(units == 'pounds')
  {
    weight.kg = weight/2.2
  }else if(units == 'kg')
  {
    weight.kg=weight
  }else
  {
    warning('The input to units is a string, and only accepts the values kg or pounds')
  }
  
  if(weight.kg >= 20)
  {
    fluids.per.day = 1500+(weight.kg-20)*20
  } else if(weight.kg >= 10)
  {
    fluids.per.day = 1000+(weight.kg-10)*50
  } else if(weight.kg < 10)
  {
    fluids.per.day = weight.kg*100
  }
  hourly.rate = fluids.per.day/24
  bolus = weight.kg*20
  fluids=list(
    'mL per hour' = hourly.rate,
    'mL per day' = fluids.per.day,
    'mL for bolus' = bolus
  )
  return(fluids)
}

# 10) 'Sodium Correction for Hyperglycemia' = sodium.correct,
sodium.correct = function(
  measured.sodium=140,
  serum.glucose=100
)
{
  corrected.sodium = measured.sodium + 0.024*(serum.glucose - 100)
  cat('Sodium corrected for hyperglycemia is: ', corrected.sodium);cat('', sep = '\n')
  return(corrected.sodium)
}
# sodium.correct()

# 'Quick SOFA score for sepsis' = qSOFA,
qSOFA = function(
  altered.mental.status='no',
  respiratory.rate=16,
  systolic.blood.pressure=120
)
{
  sofa=0
  if(respiratory.rate > 21)
  {
    sofa = sofa + 1
  }
  if(systolic.blood.pressure < 100)
  {
    sofa = sofa + 1
  }
  if(altered.mental.status == 'yes')
  {
    sofa = sofa + 1
  }
  return(sofa)
}

# 'CURB-65 Score for Pneumonia' = CURB.65,
curb65 = function(
  confusion='no',
  BUN=17,
  systolic.blood.pressure=120,
  diastolic.blood.pressure=80,
  respiratory.rate = 16
  
)
{
  guide = list(
    'high risk, 27.8% 30-day mortality' = 4,
    'Severe risk group: 14.0% 30-day mortality.' = 3,
    'Moderate risk group: 6.8% 30-day mortality.' = 2,
    'Low risk group: 2.7% 30-day mortality.'=1,
    'Low risk group: 0.6% 30-day mortality.' = 0
  )
  curb.score=0
  if(confusion == 'yes')
  {
    curb.score = curb.score + 1
  }
  if(BUN > 17)
  {
    curb.score = curb.score + 1
  }
  if(respiratory.rate > 29)
  {
    curb.score = curb.score + 1
  }
  if(systolic.blood.pressure < 90 | diastolic.blood.pressure < 61)
  {
    curb.score = curb.score + 1
  }
  res = list(
    'curb score'=curb.score, 
    'interpretation' = names(guide[guide == curb.score])
  )
  return(res)
}

# 'TIMI Risk score fo UA/nSTEMI' = TIMI.risk,
TIMI = function(
  age=65,
  Number.of.CAD.risk.factors=4,
  known.CAD='yes',
  aspirin.in.last.7.days='yes',
  number.of.angina.episodes.in.24.hours=2,
  ekg.st.changes.over.0.5='yes',
  positive.cardiac.markers='yes'
)
{
  guide = list(
    '5% mortality in 14 days' = 0,
    '5% mortality in 14 days' = 1,
    '8% mortality in 14 days' = 2,
    '13% mortality in 14 days' = 3,
    '20% mortality in 14 days' = 4,
    '26% mortality in 14 days' = 5,
    '41% mortality in 14 days' = 6,
    '41% mortality in 14 days' = 7
  )
  score=0
  if(age >= 65)
  {
    score = score + 1
  }
  if(Number.of.CAD.risk.factors >= 3)
  {
    score = score + 1
  }
  if(known.CAD == 'yes')
  {
    score = score + 1
  }
  if(aspirin.in.last.7.days == 'yes')
  {
    score = score + 1
  }
  if(ekg.st.changes.over.0.5 == 'yes')
  {
    score = score + 1
  }
  if(positive.cardiac.markers == 'yes')
  {
    score = score + 1
  }
  if(number.of.angina.episodes.in.24.hours >= 2)
  {
    score = score + 1
  }
  res = list(
    'TIMI score'=score, 
    'interpretation' = names(guide[guide == score])
  )
  return(res)
}

# Fraction of excreted urea
FEurea = function(
  serum.creatinine=1,
  urine.urea=1,
  serum.urea=1,
  urine.creatine=1
)
{
  guide = list(
    'Pre-renal' = 35,
    'Intrinsic renal' = 50
  )
  feurea =  100*((serum.creatinine*urine.urea)/(serum.urea*urine.creatine))
  interpretation = if(feurea > 50)
  {
    'Intrinsic Renal'
  }else if(feurea <= 35)
  {
    'Prerenal'
  }else
  {
    'not conclusive'
  }
  res = list(
    'fraction of excreted urea' = feurea,
    'interpretation' = interpretation
  )
  return(res)
}

# Corrected QT interval
QTc = function(
  QT.length=10,
  HR=60,
  paper.speed = 25,
  units = 'small box'
)
{
  # get rr
  RR.interval = 60/HR
  
  # get QT
  if(units == 'small box' & paper.speed == 25)
  {
    QT.interval = 40*QT.length
  }else if(units == 'small box' & paper.speed == 50)
  {
    QT.interval = 20*QT.length
  }else if(units == 'msec')
  {
      QT.interval = QT.length
  }else
  {
    warning('Could not identify QT Interval length with the information provided.
            Please make sure you provided the correct values for the variable <units>.
            The accepted values for <units> are <small box> or <msec>.')
  }
  if(exists('QT.interval'))
  {
    # get QTc from different formulas
    Bazett.QTc = QT.interval / sqrt(RR.interval)
    Fridericia.QTc = QT.interval / ((RR.interval)^(1/3) )
    Framingham.QTc = QT.interval + 154 * (1 - RR.interval)
    Hodges.QTc = QT.interval + 1.75 * ((60 / RR.interval) - 60)
    
    # return a list of QTc
    res=list(
      'Bazett' = Bazett.QTc,
      'Fridericia' = Fridericia.QTc,
      'Framingham' = Framingham.QTc,
      'Hodges' = Hodges.QTc
    )
    return(res)
  } else
  {
    warning('Could not identify QT Interval length with the information provided.
            Please make sure you provided the correct values for the variable <units>.
            The accepted values for <units> are <small box> or <msec>.
            
            Also verify that you input <paper.size> and <QT.length> variables 
            in the correct character type. Both should be of the character type
            <integer>')
  }
}


# 'MELD score' = meld.score,
# 'HAS-BLED' = has.bled,
# 'HEART' = heart.score,
# 'SIRS, Sepsis and septic shock' = SIRS.Sepsis.SepticShock,
# 'Wells Criteria for PE' = Wells.pe,
# 'Wells Criteria for DVT' = Wells.dvt,
# 'Centor Score for Strep Pharyngitis' = Centor.Strep,
# 'Child-Pugh' = Child.Pugh,
# 'Corrected QT Interval' = QTc,
# 'PERC rule for PE' = PERC.pe,
# 'Absolute Neutrophil count' = ANC,
# 'Revised Cardiac Risk index - Preoperative' = revised.cardiac.risk,
# 'NIH Stroke Scale' = NIHSS,
# "APACHE II score" = APACHE.II,
# 'CIWA score for alcohol withdrawal' = ciwar

# list of functions available
fs=list(
  # "APACHE II score" = APACHE.II,
  # 'MELD score' = meld.score,
  # 'HAS-BLED' = has.bled,
  # 'HEART' = heart.score,
  # 'SIRS, Sepsis and septic shock' = SIRS.Sepsis.SepticShock,
  # 'Wells Criteria for PE' = Wells.pe,
  # 'Wells Criteria for DVT' = Wells.dvt,
  # 'Centor Score for Strep Pharyngitis' = Centor.Strep,
  # 'Child-Pugh' = Child.Pugh,
  # 'Corrected QT Interval' = QTc,
  # 'PERC rule for PE' = PERC.pe,
  # 'Absolute Neutrophil count' = ANC,
  # 'Revised Cardiac Risk index - Preoperative' = revised.cardiac.risk,
  # 'NIH Stroke Scale' = NIHSS,
  # 'CIWA score for alcohol withdrawal' = ciwar
  
  'Fraction of Excreted urea' = FEurea,
  'Corrected QT interval' = QTc,
  'TIMI Risk score fo UA/nSTEMI' = TIMI,
  'CURB-65 Score for Pneumonia' = curb65,
  'Quick SOFA score for sepsis' = qSOFA,
  'Maintenance fluids' = Maintenance.Fluids,
  'Sodium Correction for Hyperglycemia' = sodium.correct,
  "A-a gradient" = Aa.gradient.cal,
  "Calcium Correction" = corrected.calcium.calc,
  "Creatinine Clearance" = creatinine.clearance,
  "Fraction of excreted sodium" = FENa,
  "Mean arterial pressure" = map.calc,
  'CHADS-VASc' = CHADSVASc,
  "Glasgow Comma Scale" = Glasgow,
  'ICH score' = ich.score
)

# GUI function
run.gui= function(
  
)
{
  miniGUI::miniGUI(
    title = 'inteRn',
    opFuns = fs
  )
}
